# Course_Tracking_System
The Course Tracking System is a software project built using C# and .NET that is designed to track the course records of graduate and doctoral students at the Graduate School of Sciences. The project is divided into two main parts: Student and Teacher.

<h2>Features</h2>
The Course Tracking System includes the following features:

<h3>Student</h3>

+ Students can view their profile information, including their personal information, academic program, and enrolled courses.
+ Students can track their academic progress.

<h3>Teacher</h3>

+ Teachers can view their course schedule and the list of students enrolled in their courses.


